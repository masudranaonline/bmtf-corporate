<footer class="footer">
          <div class="container-fluid">
            <div class="row">
              <div class="col-sm-6">
                <script>
                  document.write(new Date().getFullYear());
                </script>
                © Bangladesh Machine Tools Factory Ltd.
              </div>
              <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                  Developed by
                  <a href="https://evocationit.com/" target="_blank"
                    >Evocation IT</a
                  > under The Bridge Interactive
                </div>
              </div>
            </div>
          </div>
        </footer>