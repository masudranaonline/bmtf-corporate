<img src="assets/images/logo-bmtf.png" alt="BMTF_logo" width="400">
<?php /**PATH C:\xampp\htdocs\bmtf-admin\resources\views/components/application-logo.blade.php ENDPATH**/ ?>