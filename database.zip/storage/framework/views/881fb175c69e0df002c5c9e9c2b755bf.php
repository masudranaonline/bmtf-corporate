<!-- @format -->

<!DOCTYPE html>
<html
  lang="en"
  data-layout="vertical"
  data-topbar="dark"
  data-sidebar="light"
  data-sidebar-size="lg"
>
  <?php if (isset($component)) { $__componentOriginal0ff3184074c8db54ba19f0cd36718af5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0ff3184074c8db54ba19f0cd36718af5 = $attributes; } ?>
<?php $component = App\View\Components\Assets::resolve(['title' => 'Users'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('assets'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Assets::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0ff3184074c8db54ba19f0cd36718af5)): ?>
<?php $attributes = $__attributesOriginal0ff3184074c8db54ba19f0cd36718af5; ?>
<?php unset($__attributesOriginal0ff3184074c8db54ba19f0cd36718af5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0ff3184074c8db54ba19f0cd36718af5)): ?>
<?php $component = $__componentOriginal0ff3184074c8db54ba19f0cd36718af5; ?>
<?php unset($__componentOriginal0ff3184074c8db54ba19f0cd36718af5); ?>
<?php endif; ?>

  <body>
    <!-- Begin page -->
    <div id="layout-wrapper">
      <?php if (isset($component)) { $__componentOriginal2a2e454b2e62574a80c8110e5f128b60 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2a2e454b2e62574a80c8110e5f128b60 = $attributes; } ?>
<?php $component = App\View\Components\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Header::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2a2e454b2e62574a80c8110e5f128b60)): ?>
<?php $attributes = $__attributesOriginal2a2e454b2e62574a80c8110e5f128b60; ?>
<?php unset($__attributesOriginal2a2e454b2e62574a80c8110e5f128b60); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60)): ?>
<?php $component = $__componentOriginal2a2e454b2e62574a80c8110e5f128b60; ?>
<?php unset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60); ?>
<?php endif; ?>
      <div class="main-content">
        <!-- Start Page Content -->
        <div class="page-content">
          <div class="container-fluid">
            <div class="row">
              <div class="col-lg-3">
                <div class="card p-4">
                  <div class="mb-4">
                    <h2>Add User</h2>
                  </div>
                  <form action="add-user" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                      <div class="col-lg-12">
                        <div class="mb-3">
                          <label class="form-label">Name</label>
                          <input
                            type="text"
                            name="name"
                            class="form-control"
                            placeholder="Enter Name"
                          />
                        </div>
                      </div>
                      <div class="col-lg-12">
                        <div class="mb-3">
                          <label class="form-label">Email</label>
                          <input
                            type="email"
                            name="email"
                            placeholder="Enter Email"
                            class="form-control"
                          />
                        </div>
                      </div>
                      <div class="col-lg-12">
                        <div class="mb-3">
                          <label class="form-label">Password</label>
                          <input
                            type="password"
                            name="password"
                            placeholder="Enter Password"
                            class="form-control"
                          />
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-12">
                      <div class="d-flex justify-content-center">
                        <div>
                          <button
                            type="submit"
                            class="btn btn-primary px-5 mx-1"
                          >
                            Add User
                          </button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>

              <div class="col-lg-9">
                <div class="card p-4">
                  <?php if (isset($component)) { $__componentOriginalb5e767ad160784309dfcad41e788743b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb5e767ad160784309dfcad41e788743b = $attributes; } ?>
<?php $component = App\View\Components\Alert::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $attributes = $__attributesOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__attributesOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $component = $__componentOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__componentOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
                  <div id="customerList">
                    <div class="col-sm-auto">
                      <div class="row">
                        <div class="col-3">
                          <div class="search-box ms-2">
                            <input
                              type="text"
                              class="form-control search"
                              placeholder="Search..."
                            />
                            <i class="ri-search-line search-icon"></i>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="table-responsive table-card mt-3 mb-1 px-3">
                      <table
                        class="table align-middle table-nowrap"
                        id="customerTable"
                      >
                        <thead class="table-light">
                          <tr>
                            <th class="sort">Name</th>
                            <th class="sort">Email</th>
                            <th class="sort">Status</th>
                            <th class="sort" style="float: inline-end">
                              Action
                            </th>
                          </tr>
                        </thead>
                        <tbody class="list form-check-all">
                          <?php $__currentLoopData = $userList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                            <td class="searchfield1"><?php echo e($item['name']); ?></td>
                            <td class="searchfield2"><?php echo e($item['email']); ?></td>
                            <td class="searchfield5">
                              <?php if($item['status']==1): ?>
                                 <span
                                    class="badge badge-soft-success text-uppercase"
                                    >Active</span
                                  > 
                              <?php else: ?>
                                  <span
                                    class="badge badge-soft-danger text-uppercase"
                                    >Disabled</span
                                  >
                              <?php endif; ?>
                              
                            </td>
                            <td>
                              <div class="d-flex justify-content-end">
                                <div class="edit">
                                  
                                  <a class="btn btn-sm btn-success edit-item-btn d-flex align-items-center gap-1" id="<?php echo e($item['id']); ?>" onclick="openModal(this.id)">
                                    <i class="las la-pencil-alt"></i
                                    ><span>Edit</span>
                                  </a>
                                </div>
                              </div>
                            </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                      <div class="noresult" style="display: none">
                        <div class="text-center">
                          <lord-icon
                            src="https://cdn.lordicon.com/msoeawqm.json"
                            trigger="loop"
                            colors="primary:#121331,secondary:#08a88a"
                            style="width: 75px; height: 75px"
                          >
                          </lord-icon>
                          <h5 class="mt-2">Sorry! No Result Found</h5>
                        </div>
                      </div>
                    </div>
                    <div class="d-flex justify-content-end">
                      <div class="pagination-wrap hstack gap-2">
                        <a class="page-item pagination-prev disabled" href="#">
                          Previous
                        </a>
                        <ul class="pagination listjs-pagination mb-0"></ul>
                        <a class="page-item pagination-next" href="#"> Next </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!--------------_Edit Modal---------------->
        <div
          class="modal fade"
          id="userEditModal"
          data-bs-backdrop="static"
          data-bs-keyboard="false"
          tabindex="-1"
          aria-labelledby="exampleModalgridLabel"
          aria-modal="true"
        >
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalgridLabel">
                  Edit User
                </h5>
                <button
                  type="button"
                  class="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                ></button>
              </div>
              <div class="modal-body">
                <form action="">

                  <input type="hidden" name="user_id" id="edit_user_id">
                  <div class="row">
                    <div class="col-lg-12">
                      <div class="mb-3">
                        <label class="form-label">Name</label>
                        <input
                          type="text"
                          class="form-control"
                          placeholder="Enter Name"
                          id="edit_name"
                        />
                      </div>
                    </div>
                    <div class="col-lg-12">
                      <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input
                          type="email"
                          placeholder="Enter Email"
                          class="form-control"
                          id="edit_email"
                        />
                      </div>
                    </div>
                    <div class="col-lg-12">
                      <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input
                          type="password"
                          placeholder="Enter Password"
                          class="form-control"

                        />
                      </div>
                    </div>
                    <div class="col-lg-12">
                      <div>
                        <label
                          for=""
                          class="form-label d-flex align-items-center"
                          >Status
                          <i
                            class="las la-question-circle tooltip-icon mx-1"
                            data-bs-toggle="tooltip"
                            data-bs-placement="top"
                            title="Status"
                            rel="tooltip"
                          ></i
                        ></label>
                        <select id="" placeholder="Choose Status" id="edit_status">
                          <option value="1">Active</option>
                          <option value="0">Disable</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-12">
                    <div class="d-flex justify-content-center">
                      <div>
                        <button type="submit" class="btn btn-primary px-5 mx-1">
                          Edit
                        </button>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        
        <!-- End Page-content -->

        <?php if (isset($component)) { $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $attributes; } ?>
<?php $component = App\View\Components\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $attributes = $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $component = $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>
      </div>
      <!-- end main content-->
    </div>
    <!-- END layout-wrapper -->

    <?php if (isset($component)) { $__componentOriginal7ab197232c97c7955fb023ba2629a718 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ab197232c97c7955fb023ba2629a718 = $attributes; } ?>
<?php $component = App\View\Components\Scripts::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Scripts::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ab197232c97c7955fb023ba2629a718)): ?>
<?php $attributes = $__attributesOriginal7ab197232c97c7955fb023ba2629a718; ?>
<?php unset($__attributesOriginal7ab197232c97c7955fb023ba2629a718); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ab197232c97c7955fb023ba2629a718)): ?>
<?php $component = $__componentOriginal7ab197232c97c7955fb023ba2629a718; ?>
<?php unset($__componentOriginal7ab197232c97c7955fb023ba2629a718); ?>
<?php endif; ?>
    <script>
      function openModal(clicked_id) {
            $("#userEditModal").modal("show");

            $.ajax({
                url: '/edit-user' + clicked_id
                , type: "GET"
                , success: function(response) {
                    console.log(response);
                    $('#edit_name').val(response.data.name);
                    $('#edit_email').val(response.data.email);
                    $('#edit_status').val(response.data.status);
                    $('#edit_user_id').val(clicked_id);
                }
            });

        }
    </script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\bmtf-admin\resources\views/pages/user.blade.php ENDPATH**/ ?>