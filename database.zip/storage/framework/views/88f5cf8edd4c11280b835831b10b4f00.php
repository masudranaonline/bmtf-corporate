<?php if(session()->has('status')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('status')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>                       <?php /**PATH C:\xampp\htdocs\bmtf-admin\resources\views/components/alert.blade.php ENDPATH**/ ?>