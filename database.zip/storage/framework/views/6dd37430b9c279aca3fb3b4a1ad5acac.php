<!-- @format -->

<!DOCTYPE html>
<html
  lang="en"
  data-layout="vertical"
  data-topbar="dark"
  data-sidebar="light"
  data-sidebar-size="lg"
>
  <?php if (isset($component)) { $__componentOriginal0ff3184074c8db54ba19f0cd36718af5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0ff3184074c8db54ba19f0cd36718af5 = $attributes; } ?>
<?php $component = App\View\Components\Assets::resolve(['title' => 'Clients'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('assets'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Assets::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0ff3184074c8db54ba19f0cd36718af5)): ?>
<?php $attributes = $__attributesOriginal0ff3184074c8db54ba19f0cd36718af5; ?>
<?php unset($__attributesOriginal0ff3184074c8db54ba19f0cd36718af5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0ff3184074c8db54ba19f0cd36718af5)): ?>
<?php $component = $__componentOriginal0ff3184074c8db54ba19f0cd36718af5; ?>
<?php unset($__componentOriginal0ff3184074c8db54ba19f0cd36718af5); ?>
<?php endif; ?>

  <body>
    <!-- Begin page -->
    <div id="layout-wrapper">
      <?php if (isset($component)) { $__componentOriginal2a2e454b2e62574a80c8110e5f128b60 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2a2e454b2e62574a80c8110e5f128b60 = $attributes; } ?>
<?php $component = App\View\Components\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Header::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2a2e454b2e62574a80c8110e5f128b60)): ?>
<?php $attributes = $__attributesOriginal2a2e454b2e62574a80c8110e5f128b60; ?>
<?php unset($__attributesOriginal2a2e454b2e62574a80c8110e5f128b60); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60)): ?>
<?php $component = $__componentOriginal2a2e454b2e62574a80c8110e5f128b60; ?>
<?php unset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60); ?>
<?php endif; ?>
      <div class="main-content">
        <!-- Start Page Content -->
        <div class="page-content">
          <div class="container-fluid">
            <div class="row">
              <div class="col-lg-3">
                <div class="card p-4">
                  <div class="mb-4">
                    <h2>Add Client</h2>
                  </div>
                  <form action="add-client" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                      <div class="col-lg-12">
                        <div class="mb-3">
                          <label class="form-label">Client Name</label>
                          <input
                            type="text"
                            name="name"
                            class="form-control"
                            placeholder="Enter Client Name"
                          />
                        </div>
                      </div>
                      <div class="col-lg-12">
                        <div class="mb-3">
                          <label class="form-label">Client Logo</label>
                          <input
                            type="file"
                            name="file"
                            placeholder="Upload Your File"
                            class="form-control <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            accept="image/*"
                          />
                        </div>
                        <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                    <div class="col-lg-12">
                      <div class="d-flex justify-content-center">
                        <div>
                          <button
                            type="submit"
                            class="btn btn-primary px-5 mx-1"
                          >
                            ADD
                          </button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
              <div class="col-lg-9">
                <div class="card p-4">
                  <?php if (isset($component)) { $__componentOriginalb5e767ad160784309dfcad41e788743b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb5e767ad160784309dfcad41e788743b = $attributes; } ?>
<?php $component = App\View\Components\Alert::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $attributes = $__attributesOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__attributesOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $component = $__componentOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__componentOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
                  <div id="customerList">
                    <div class="row g-4 mb-3">
                      <div class="col-sm-auto">
                        <div class="">
                          <div class="search-box ms-2">
                            <input
                              type="text"
                              class="form-control search"
                              placeholder="Search..."
                            />
                            <i class="ri-search-line search-icon"></i>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="table-responsive table-card mt-3 mb-1 px-3">
                      <table
                        class="table align-middle table-nowrap"
                        id="customerTable"
                      >
                        <thead class="table-light">
                          <tr>
                            <th class="sort">#</th>
                            <th class="sort">Name</th>
                            <th class="sort">Logo</th>
                            <th class="sort">Status</th>
                            <th class="sort" style="float: inline-end">
                              Action
                            </th>
                          </tr>
                        </thead>
                        <tbody class="list form-check-all">
                          <?php $__currentLoopData = $clientList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td class="searchfield1"><?php echo e($item['name']); ?></td>
                            <td>
                              <div>
                                <img
                                  style="width: 30px"
                                  src="<?php echo e($item->logo); ?>"
                                  alt="project 1"
                                />
                              </div>
                            </td>
                            <td class="searchfield2">
                              <?php if($item->status==1): ?>
                                  <span
                                class="badge badge-soft-success text-uppercase"
                                >Active</span
                              >
                              <?php else: ?>
                                  <span
                                class="badge badge-soft-danger text-uppercase"
                                >Disabled</span
                              >
                              <?php endif; ?>
                              
                            </td>
                            <td>
                              <div class="d-flex justify-content-end">
                                <div class="edit">
                                  <button
                                    class="btn btn-sm btn-success edit-item-btn d-flex align-items-center gap-1"
                                    data-bs-toggle="modal"
                                    data-bs-target="#clientEditModal"
                                  >
                                    <i class="las la-pencil-alt"></i
                                    ><span>Edit</span>
                                  </button>
                                </div>
                              </div>
                            </td>
                          </tr> 
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                        </tbody>
                      </table>
                      <div class="noresult" style="display: none">
                        <div class="text-center">
                          <lord-icon
                            src="https://cdn.lordicon.com/msoeawqm.json"
                            trigger="loop"
                            colors="primary:#121331,secondary:#08a88a"
                            style="width: 75px; height: 75px"
                          >
                          </lord-icon>
                          <h5 class="mt-2">Sorry! No Result Found</h5>
                        </div>
                      </div>
                    </div>
                    <div class="d-flex justify-content-end">
                      <div class="pagination-wrap hstack gap-2">
                        <a class="page-item pagination-prev disabled" href="#">
                          Previous
                        </a>
                        <ul class="pagination listjs-pagination mb-0"></ul>
                        <a class="page-item pagination-next" href="#"> Next </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!--------------_Edit Modal---------------->
        <div
          class="modal fade"
          id="clientEditModal"
          data-bs-backdrop="static"
          data-bs-keyboard="false"
          tabindex="-1"
          aria-labelledby="exampleModalgridLabel"
          aria-modal="true"
        >
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalgridLabel">
                  Edit Client
                </h5>
                <button
                  type="button"
                  class="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                ></button>
              </div>
              <div class="modal-body">
                <form action="">
                  <div class="row">
                    <div class="col-lg-12">
                      <div class="mb-3">
                        <label class="form-label">Client Name</label>
                        <input
                          type="text"
                          class="form-control"
                          placeholder="Enter Client Name"
                        />
                      </div>
                    </div>
                    <div class="col-lg-12">
                      <div class="mb-3">
                        <label class="form-label">Client Logo</label>
                        <input
                          type="file"
                          placeholder="Upload Your File"
                          class="form-control"
                        />
                      </div>
                    </div>
                    <div class="col-lg-12">
                      <div>
                        <label
                          for=""
                          class="form-label d-flex align-items-center"
                          >Status
                          <i
                            class="las la-question-circle tooltip-icon mx-1"
                            data-bs-toggle="tooltip"
                            data-bs-placement="top"
                            title="Status"
                            rel="tooltip"
                          ></i
                        ></label>
                        <select id="" placeholder="Choose Status">
                          <option value="">Select a status...</option>
                          <option>Active</option>
                          <option>Disable</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-12">
                    <div class="d-flex justify-content-center">
                      <div>
                        <button type="submit" class="btn btn-primary px-5 mx-1">
                          Edit
                        </button>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        
        <!-- End Page-content -->

        <?php if (isset($component)) { $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $attributes; } ?>
<?php $component = App\View\Components\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $attributes = $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $component = $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>
      </div>
      <!-- end main content-->
    </div>
    <!-- END layout-wrapper -->

    <?php if (isset($component)) { $__componentOriginal7ab197232c97c7955fb023ba2629a718 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ab197232c97c7955fb023ba2629a718 = $attributes; } ?>
<?php $component = App\View\Components\Scripts::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Scripts::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ab197232c97c7955fb023ba2629a718)): ?>
<?php $attributes = $__attributesOriginal7ab197232c97c7955fb023ba2629a718; ?>
<?php unset($__attributesOriginal7ab197232c97c7955fb023ba2629a718); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ab197232c97c7955fb023ba2629a718)): ?>
<?php $component = $__componentOriginal7ab197232c97c7955fb023ba2629a718; ?>
<?php unset($__componentOriginal7ab197232c97c7955fb023ba2629a718); ?>
<?php endif; ?>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\bmtf-admin\resources\views/pages/client.blade.php ENDPATH**/ ?>