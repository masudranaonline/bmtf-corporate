<!-- @format -->

<!DOCTYPE html>
<html
  lang="en"
  data-layout="vertical"
  data-topbar="dark"
  data-sidebar="light"
  data-sidebar-size="lg"
>
  <?php if (isset($component)) { $__componentOriginal0ff3184074c8db54ba19f0cd36718af5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0ff3184074c8db54ba19f0cd36718af5 = $attributes; } ?>
<?php $component = App\View\Components\Assets::resolve(['title' => 'Dashboard'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('assets'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Assets::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0ff3184074c8db54ba19f0cd36718af5)): ?>
<?php $attributes = $__attributesOriginal0ff3184074c8db54ba19f0cd36718af5; ?>
<?php unset($__attributesOriginal0ff3184074c8db54ba19f0cd36718af5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0ff3184074c8db54ba19f0cd36718af5)): ?>
<?php $component = $__componentOriginal0ff3184074c8db54ba19f0cd36718af5; ?>
<?php unset($__componentOriginal0ff3184074c8db54ba19f0cd36718af5); ?>
<?php endif; ?>

  <body>
    <!-- Begin page -->
    <div id="layout-wrapper">
      <?php if (isset($component)) { $__componentOriginal2a2e454b2e62574a80c8110e5f128b60 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2a2e454b2e62574a80c8110e5f128b60 = $attributes; } ?>
<?php $component = App\View\Components\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Header::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2a2e454b2e62574a80c8110e5f128b60)): ?>
<?php $attributes = $__attributesOriginal2a2e454b2e62574a80c8110e5f128b60; ?>
<?php unset($__attributesOriginal2a2e454b2e62574a80c8110e5f128b60); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60)): ?>
<?php $component = $__componentOriginal2a2e454b2e62574a80c8110e5f128b60; ?>
<?php unset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60); ?>
<?php endif; ?>
      <div class="main-content">
        <!-- Start Page Content -->
        <div class="page-content">
          <div class="container-fluid">
            <div class="row">
              <div class="col-xl-3 col-md-6">
                <!-- card -->
                <div class="card card-animate">
                  <div class="card-body">
                    <div class="d-flex align-items-center">
                      <div class="flex-grow-1 overflow-hidden">
                        <p
                          class="text-uppercase fw-medium text-muted text-truncate mb-0"
                        >
                          Total Project
                        </p>
                      </div>
                    </div>
                    <div
                      class="d-flex align-items-end justify-content-between mt-4"
                    >
                      <div>
                        <h4 class="fs-36 fw-semibold ff-secondary mb-4">10</h4>
                        <a href="#" class="text-decoration-underline"
                          >View All Project</a
                        >
                      </div>
                      <div class="avatar-sm flex-shrink-0">
                        <span
                          class="avatar-title bg-success-subtle rounded fs-3"
                        >
                          <i class="bx bx-user text-success"></i>
                        </span>
                      </div>
                    </div>
                  </div>
                  <!-- end card body -->
                </div>
                <!-- end card -->
              </div>
              <!-- end col -->

              <div class="col-xl-3 col-md-6">
                <!-- card -->
                <div class="card card-animate">
                  <div class="card-body">
                    <div class="d-flex align-items-center">
                      <div class="flex-grow-1 overflow-hidden">
                        <p
                          class="text-uppercase fw-medium text-muted text-truncate mb-0"
                        >
                          News
                        </p>
                      </div>
                    </div>
                    <div
                      class="d-flex align-items-end justify-content-between mt-4"
                    >
                      <div>
                        <h4 class="fs-36 fw-semibold ff-secondary mb-4">5</h4>
                        <a href="#" class="text-decoration-underline"
                          >View all News</a
                        >
                      </div>
                      <div class="avatar-sm flex-shrink-0">
                        <span class="avatar-title bg-info-subtle rounded fs-3">
                          <i class="bx bxs-user-pin text-info"></i>
                        </span>
                      </div>
                    </div>
                  </div>
                  <!-- end card body -->
                </div>
                <!-- end card -->
              </div>
              <!-- end col -->

              <div class="col-xl-3 col-md-6">
                <!-- card -->
                <div class="card card-animate">
                  <div class="card-body">
                    <div class="d-flex align-items-center">
                      <div class="flex-grow-1 overflow-hidden">
                        <p
                          class="text-uppercase fw-medium text-muted text-truncate mb-0"
                        >
                          Active NOC
                        </p>
                      </div>
                    </div>
                    <div
                      class="d-flex align-items-end justify-content-between mt-4"
                    >
                      <div>
                        <h4 class="fs-36 fw-semibold ff-secondary mb-4">4</h4>
                        <a href="#" class="text-decoration-underline"
                          >View NOC</a
                        >
                      </div>
                      <div class="avatar-sm flex-shrink-0">
                        <span
                          class="avatar-title bg-warning-subtle rounded fs-3"
                        >
                          <i class="bx bx-clipboard text-warning"></i>
                        </span>
                      </div>
                    </div>
                  </div>
                  <!-- end card body -->
                </div>
                <!-- end card -->
              </div>
              <!-- end col -->

              <div class="col-xl-3 col-md-6">
                <!-- card -->
                <div class="card card-animate">
                  <div class="card-body">
                    <div class="d-flex align-items-center">
                      <div class="flex-grow-1 overflow-hidden">
                        <p
                          class="text-uppercase fw-medium text-muted text-truncate mb-0"
                        >
                          Career Opportunity
                        </p>
                      </div>
                    </div>
                    <div
                      class="d-flex align-items-end justify-content-between mt-4"
                    >
                      <div>
                        <h4 class="fs-36 fw-semibold ff-secondary mb-4">2</h4>
                        <a href="#" class="text-decoration-underline"
                          >View All Career Opportunity</a
                        >
                      </div>
                      <div class="avatar-sm flex-shrink-0">
                        <span
                          class="avatar-title bg-primary-subtle rounded fs-3"
                        >
                          <i class="bx bx-headphone text-primary"></i>
                        </span>
                      </div>
                    </div>
                  </div>
                  <!-- end card body -->
                </div>
                <!-- end card -->
              </div>
              <!-- end col -->
            </div>
          </div>
          <!-- container-fluid -->
        </div>
        <!-- End Page-content -->

        <?php if (isset($component)) { $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $attributes; } ?>
<?php $component = App\View\Components\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $attributes = $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $component = $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>
      </div>
      <!-- end main content-->
    </div>
    <!-- END layout-wrapper -->

    <?php if (isset($component)) { $__componentOriginal7ab197232c97c7955fb023ba2629a718 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ab197232c97c7955fb023ba2629a718 = $attributes; } ?>
<?php $component = App\View\Components\Scripts::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Scripts::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ab197232c97c7955fb023ba2629a718)): ?>
<?php $attributes = $__attributesOriginal7ab197232c97c7955fb023ba2629a718; ?>
<?php unset($__attributesOriginal7ab197232c97c7955fb023ba2629a718); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ab197232c97c7955fb023ba2629a718)): ?>
<?php $component = $__componentOriginal7ab197232c97c7955fb023ba2629a718; ?>
<?php unset($__componentOriginal7ab197232c97c7955fb023ba2629a718); ?>
<?php endif; ?>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\bmtf-admin\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>